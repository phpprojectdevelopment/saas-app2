<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;

class APIcrudController extends Controller
{
	public function updateUserDetails(){
		$name = trim(request()->input('name'));
		$email_id = trim(request()->input('email_id'));
		$mobile_no = trim(request()->input('mobile_no'));
		$gender = trim(request()->input('gender'));
		$location = trim(request()->input('location'));
		$genderList = ['male','female'];
		$data = ['name'=>$name,'gender'=>$gender,'location'=>$location];

		if($name==null || $name==''){
			return response()->json(['status'=>'failed', 'message'=>'Name field cannot be blank']);
		}
		if(preg_match('/[^a-zA-Z ]/',$name)){
			return response()->json(['status'=>'failed', 'message'=>'Special characters not allowed in Name field']);
		}
		if(!in_array($gender,$genderList)){
			return response()->json(['status'=>'failed', 'message'=>'Invalid data provided for Gender']);	
		}
		if($location==null || $location==''){
			return response()->json(['status'=>'failed', 'message'=>'Location field cannot be blank']);
		}
		if(strlen($location)>45){
			return response()->json(['status'=>'failed', 'message'=>'Characters limit exceeded for location, please use only 45 characters including spaces']);	
		}
		
		if($email_id){
			if($this->isValidEmail($email_id)==null || $this->isValidEmail($email_id)==''){
				return response()->json(['status'=>'failed', 'message'=>'Invalid Email ID']);
			}
			if($this->emailExist($email_id)<1){
				return response()->json(['status'=>'failed', 'message'=>'Email not exists in the database']);	
			}

			$updated_data = User::where(['email_id'=>$email_id])->update($data);
			if($updated_data==1){
				return response()->json(['status'=>'success', 'message'=>'Record updated successfully','data'=>$this->getEmailUser($email_id)]);	
			}
			
			return response()->json(['status'=>'failed', 'message'=>'Something went wrong, please try again after sometime']);
		}
		if($mobile_no){
			if(!is_numeric($mobile_no) || $mobile_no==null || $mobile_no=='' || strlen($mobile_no)>10 || strlen($mobile_no)<10){
				return response()->json(['status'=>'failed', 'message'=>'Invalid mobile number']);	
			}
			if($this->mobileExist($mobile_no)<1){
				return response()->json(['status'=>'failed', 'message'=>'Mobile number not exists in the database']);	
			}

			$updated_data = User::where(['mobile_no'=>$mobile_no])->update($data);
			if($updated_data==1){
				return response()->json(['status'=>'success', 'message'=>'Record updated successfully','data'=>$this->getMobileUser($mobile_no)]);	
			}
			
			return response()->json(['status'=>'failed', 'message'=>'Something went wrong, please try again after sometime']);
		}
	}
	public function userList(){
		$mobile_no = request()->input('mobile_no');
		if($mobile_no){
			if($this->mobileExist($mobile_no)<1){
				return response()->json(['status'=>'failed', 'message'=>'Mobile number not exists in the database']);	
			}
			$userList = User::where(['mobile_no'=>$mobile_no])->select('name','email_id','mobile_no','gender','location')->get();
			return response()->json(['status'=>'success', 'message'=>'Record available', 'user_list'=>$userList]);
		}
		$userList = User::select('name','email_id','mobile_no','gender','location')->get();
		return response()->json(['status'=>'success', 'message'=>'Record available', 'user_list'=>$userList]);
	}
	public function getEmailUser($email_id){
		if($email_id!=null){
			return User::where(['email_id'=>$email_id])->select('name','email_id','mobile_no','gender','location')->get();
		}
	}
	public function getMobileUser($mobile_no){
		if($mobile_no!=null){
			return User::where(['mobile_no'=>$mobile_no])->select('name','email_id','mobile_no','gender','location')->get();
		}
	}
	public function isValidEmail($email) {
		$email = filter_var($email, FILTER_SANITIZE_EMAIL);
    	return filter_var($email, FILTER_VALIDATE_EMAIL) && preg_match('/@.+\./', $email);
	}
	public function emailExist($email){
		return User::where(['email_id'=>$email])->count();
	}
	public function mobileExist($mobile){
		return User::where(['mobile_no'=>$mobile])->count();
	}
}