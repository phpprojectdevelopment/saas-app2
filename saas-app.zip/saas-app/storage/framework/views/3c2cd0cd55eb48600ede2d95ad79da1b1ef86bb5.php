<?php $__env->startSection('title','| Test Drive Schedular | Buying Tools '); ?>

<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
       
    <div id="slider-wrap">
        <div id="slider" class="carousel slide inner" data-ride="carousel" data-interval="0"
            data-pause="false">
            <div class="carousel-inner">
                <div class="item active">
                    <img data-desktop-src="public/images/banner/test-drive-scheduler.jpg" data-mobile-src="public/images/banner/test-drive-scheduler-mobile.jpg" alt="Aher Autoprime - Schedule a Test Drive ">
                </div>
            </div>
            <div class="carousel-navigation">
                <a class="left carousel-control" href="#slider" role="button" data-slide="prev"><span
                    class="glyphicon glyphicon-chevron-left icon-left-open-big" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span> </a><a class="right carousel-control" href="#slider"
                        role="button" data-slide="next"><span class="glyphicon glyphicon-chevron-right icon-right-open-big"
                            aria-hidden="true"></span><span class="sr-only">Next</span> </a>
            </div>
            <div class="clearfix">
            </div>
        </div>
    </div>
    <div id="PageContent" class="pad30 test-drive">

        <div class="container">

            <h1 class="section-head">Test Drive Scheduler</h1>
        </div>
        <div class="bg-grey">
            <div class="container">
                <p>
                   Aher Autoprime, in its endeavor to give the best buying experience to its customers, offers to give "Test Drive" of Maruti Cars, in Kalyan city.
                </p>
                <p>
                   Incase you wish to Test Drive the Maruti Car, before deciding to purchase it, we at Aher Autoprime would be more than happy to offer you the same. Please fill the form below, and submit, one of our Executive will be in touch with you to arrange a Test Drive, at a mutually convenient time. 
                </p>
                <div class="col-md-6 form-wrap">
                    <div class="row">
                        <div class="col-xs-12 form-group form no-padding">

                           
                           
                            
                            <div class="form-group">
                                <label for="Type" class="col-sm-3 control-label">
                                    Name*</label>
                                <div class="col-sm-8">
                                    <input name="ctl00$ContentPlaceHolder1$txtName" type="text" id="ctl00_ContentPlaceHolder1_txtName" class="form-control" />
                                    <span id="ctl00_ContentPlaceHolder1_rfvName" class="text-danger" style="display:none;">Please specify name</span>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="Type" class="col-sm-3 control-label">
                                    Email Id*</label>
                                <div class="col-sm-8">
                                    <input name="ctl00$ContentPlaceHolder1$txtEmail" type="text" id="ctl00_ContentPlaceHolder1_txtEmail" class="form-control" />
                                    <input name="ctl00$ContentPlaceHolder1$txtSecEmail" type="text" id="ctl00_ContentPlaceHolder1_txtSecEmail" class="secemail" />
                                    <span id="ctl00_ContentPlaceHolder1_rfvEmailId" class="text-danger" style="display:none;">Please specify email id.</span>
                                    <span id="ctl00_ContentPlaceHolder1_revEmailId" class="text-danger" style="display:none;">Please enter valid email address</span>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="Type" class="col-sm-3 control-label">
                                    Contact No*</label>
                                <div class="col-sm-8">
                                    <input name="ctl00$ContentPlaceHolder1$txtContactNo" type="text" id="ctl00_ContentPlaceHolder1_txtContactNo" class="form-control" />
                                    <span id="ctl00_ContentPlaceHolder1_rfvContactNo" class="text-danger" style="display:none;">Please specify contact no.</span>
                                    <span id="ctl00_ContentPlaceHolder1_revTelno" class="text-danger" style="display:none;">Please specify valid contact no.</span>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="Type" class="col-sm-3 control-label">
                                    Location</label>
                                <div class="col-sm-8">
                                    <select name="ctl00$ContentPlaceHolder1$ddlLocation" id="ctl00_ContentPlaceHolder1_ddlLocation" class="form-control">
    <option value="1">Kalyan</option>

</select>
                                    
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="Type" class="col-sm-3 control-label">
                                    Car Model</label>
                                <div class="col-sm-8">
                                    <select name="ctl00$ContentPlaceHolder1$ddlTestDriveModel" id="ctl00_ContentPlaceHolder1_ddlTestDriveModel" class="form-control ddtestdrivemodel">
    <option value="-1" ModelID="-1">Select Car</option>
    <option value="ALTO-K10" ModelID="21">ALTO K10</option>
    <option value="ALTO-800" ModelID="22">ALTO 800</option>
    <option value="SWIFT-DZIRE" ModelID="23">SWIFT DZIRE</option>
    <option value="Swift" ModelID="9">Swift</option>
    <option value="Celerio" ModelID="6">Celerio</option>
    <option value="Wagon-R" ModelID="4">Wagon R</option>
    <option value="Ertiga" ModelID="2">Ertiga</option>
    <option value="Omni" ModelID="7">Omni</option>
    <option value="Dzire" ModelID="11">Dzire</option>
    <option value="Eeco" ModelID="13">Eeco</option>
    <option value="Ciaz" ModelID="16">Ciaz</option>
    <option value="Vitara-Brezza" ModelID="17">Vitara Brezza</option>

</select>
                                    <span id="ctl00_ContentPlaceHolder1_rfvCars" class="text-danger" style="display:none;">Please select car model</span>
                                </div>
                            </div>
                            

                            <label for="Type" class="col-sm-3 control-label">
                            </label>
                            <div class="col-sm-8">
                                <input type="submit" name="ctl00$ContentPlaceHolder1$btnSubmit" value="Submit" onclick="return ReturnValidate();WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ctl00$ContentPlaceHolder1$btnSubmit&quot;, &quot;&quot;, true, &quot;ValidateTestDrive&quot;, &quot;&quot;, false, false))" id="ctl00_ContentPlaceHolder1_btnSubmit" class="btn btn-maruti col-md-4" />
                            </div>
                            <div class="clearfix">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="container pad">

            <p class="no-margin">
                
              I agree that by clicking "Submit", I am explicitly soliciting a call or message from the Aher Autoprime or its associates on my number to assist me.  
            </p>
        </div>
    </div>
    <script src="js/jquery-2.1.1.min.js" type="text/javascript"></script>
    <script type="text/javascript">

        $('.LocationToggle').change(function () {
            ShowLocation();
        });

        function ShowLocation() {
            if ($('table[id$="rbLocation"]  input:checked').val() == "1") {
                $('#mylocation').removeClass('hide');
                $('#showroom').addClass('hide');
            }
            else {
                $('#showroom').removeClass('hide');
                $('#mylocation').addClass('hide');
            }
        }
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>