<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <style type="text/css">
        .info,.pagination-wrap{
            text-align: center;
            }
        h2{
            padding: 10px;
            }
        .homepage{
            margin-top: 50px;
            text-align: center;
            }
        th,td{
            border: 1px solid gray;
            padding:5px;
            }
            
            
        .form-control {
            display: block;
            width: 20%;
            height: 34px;
            padding: 6px 12px;
            font-size: 14px;
            line-height: 1.42857143;
            color: #555;
            background-color: #fff;
            background-image: none;
            border: 1px solid #ccc;
            border-radius: 4px;
            }
          
        body{
            background: #DADADA;
        }
         input{ 
            padding: 12px 20px;
            margin: 8px 0; 
            border: 3px solid #ccc;
            -webkit-transition: 0.5s;
            transition: 0.5s;
            outline: none;
        }

        input[type=text]:focus {
            border: 3px solid #555;
        }
           .btn {
                background: #f68a1e;
                color: #fff;
                border-color: #f68a1e;
                padding: 10px 50px;
                transition: 0.5s all ease-in-out;
                -mz-transition: 0.5s all ease-in-out;
                border-radius: 0;
                margin-top: 15px;
            }

                .btn:hover {
                    background: #333;
                    color: #fff;
                    border-color: #333;
                }
         
         
    </style>
</head>
<body style="padding-top:100px;">
    <div class="container">
      <div class="info">
        <div class="col-md-6 col-md-offset-3">
           <center><h4></span>Log in with your credentials<span class="glyphicon glyphicon-user"></h4><br/></center>
            <div class="block-margin-top">
                <form action="admin/checkLogin" method="POST" class="form-signin col-md-8 col-md-offset-2"  role="form">
                   <?php echo e(csrf_field()); ?>  
                   <center> <input type="text" name="username" class="form-control" placeholder="Username" required autofocus /><br/><br/>
                    <input type="password" name="password" class="form-control" placeholder="Password" required /><br/><br/> 
                    <button type="submit" class="btn btn-default">Submit</button></center>
                </form>
            </div>
        </div>
      </div>
    </div> 
</body>
</html>