 <?php echo $__env->make('includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;
 <div class="container">  
      <h3 align="center">Students Records</h3>
      <div ng-app="studentApp" ng-controller="studendCtrl" ng-init="loadStudentClass();">
      	<div style="max-width:200px; float:right;">
		<label for="male">Select class:&nbsp;</label>
		<select ng-model="student_class" ng-change="loadStudentData(student_class)" style="float:right;">
			<option ng-repeat="student_class in student_class_list" value="{{student_class}}" ng-init="loadStudentData(student_class)">{{student_class}}</option>
		</select>
		</div>
		<table>
		  <tr ng-repeat="x in student_list">
		    <td></td>
		  </tr>
	  	</table>

	  	<table id="customers">
		  <tr>
		    <th>Student Name</th>
		    <th>Class</th>
		    <th>Age</th>
		    <th>Admission Date</th>
		  </tr>
		  <tr ng-repeat="x in student_list">
		    <td>{{x.student_name}}</td>
		    <td>{{x.class}}</td>
		    <td>{{x.age}}</td>
		    <td>{{x.admission_date}}</td>
		  </tr>
		  
			</table>
	  </div>	  
 </div>
<?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;