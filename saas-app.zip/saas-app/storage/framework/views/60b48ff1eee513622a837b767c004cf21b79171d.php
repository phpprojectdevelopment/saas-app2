<?php $__env->startSection('content'); ?>
    <div class="row">
    	<div class="col-lg-12 margin-tb">
	        <div class="pull-left">
	            <h2>Laravel 5.7 CRUD Example from scratch - Ottoedge.com</h2>
	        </div>
	        <div class="pull-right">
				<a href="<?php echo e(route('products.create')); ?>">Create New Product</a>
			</div>
        </div>
    </div>
	
	<?php if($message = Session::get('success')): ?>
	<div class="alert alert-success">
			<p><?php echo e($message); ?></p>
	</div>
	<?php endif; ?>

	<table class="table table-bordered">
		<tr>
			<th>No</th>
			<th>Name</th>
			<th>Details</th>
			<th width="280px">Action</th>
		</tr>
		<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e(++$i); ?></td>
			<td><?php echo e($product->name); ?></td>
			<td><?php echo e($product->detail); ?></td>
			<td>
				<form method="post" action="<?php echo e(route('products.destroy', $product->id)); ?>">
					<a class="btn btn-info" href="<?php echo e(route('products.show', $product->id)); ?>">Show</a>
					<a class="btn btn-primary" href="<?php echo e(route('products.edit', $product->id)); ?>">Edit</a>

					<?php echo e(csrf_field()); ?>

					<?php echo e(method_field('DELETE')); ?>


					<input type="submit" value="Delete" class="btn btn-danger">
				</form>
			</td>
		</tr>	
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>

	<?php echo $products->links(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('products.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>